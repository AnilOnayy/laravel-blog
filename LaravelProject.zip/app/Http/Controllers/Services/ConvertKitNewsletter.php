<?php

namespace App\Http\Controllers\Services;

class ConvertKitNewsletter implements Newsletter
{
    public function subscribe(string $email,string $list) {

    }
}
