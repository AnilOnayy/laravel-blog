<div class="mb-6">
    {{ $slot }}
</div>
