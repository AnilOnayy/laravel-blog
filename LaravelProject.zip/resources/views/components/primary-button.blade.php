<button type="submit" class="bg-blue-800 text-white rounded py-2 px-4 hover:bg-blue-800 rounded">
    {{ $slot }}
</button>
