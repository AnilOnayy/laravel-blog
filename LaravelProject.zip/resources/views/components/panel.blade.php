<div {{ $attributes(['class' => 'max-w-6xl mx-auto mt-10 lg:mt-20 space-y-6 border  border-gray-300 p-6 rounded']) }} >
{{ $slot }}
</div>
