<div class="mb-6">
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/anilonay/Desktop/learn-php-laravel/laravel-blog/resources/views/components/form/field.blade.php ENDPATH**/ ?>