<div <?php echo e($attributes(['class' => 'max-w-6xl mx-auto mt-10 lg:mt-20 space-y-6 border  border-gray-300 p-6 rounded'])); ?> >
<?php echo e($slot); ?>

</div>
<?php /**PATH /home/anilonay/Desktop/learn-php-laravel/laravel-blog/resources/views/components/panel.blade.php ENDPATH**/ ?>