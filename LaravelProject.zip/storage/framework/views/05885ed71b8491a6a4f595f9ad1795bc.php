<button type="submit" class="bg-blue-800 text-white rounded py-2 px-4 hover:bg-blue-800 rounded">
    <?php echo e($slot); ?>

</button>
<?php /**PATH /home/anilonay/Desktop/learn-php-laravel/laravel-blog/resources/views/components/primary-button.blade.php ENDPATH**/ ?>